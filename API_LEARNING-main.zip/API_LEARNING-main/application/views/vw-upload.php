<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiy="X-UA-Compatible content="ie=edge>
    <title>File Uploading</title>
</head> 
<body>
    <h1>File Uploading</h1>
    <form action="upload/upload_file" method="post" enctype="multipart/form-data"> 
    <input type="file" name="image" id="images">
    <input type="submit" value="Upload"›
	</form>
</body> 
</html>
